package xmlweather;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import nu.xom.*;

public class XMLWeather {
    int[] highTemp = new int[7];
    int[] lowTemp = new int[7];
    String[] conditions = new String[7];
    
    public XMLWeather() throws ParsingException, IOException {
        try {        
            //get the xml file from the web and store the info locally in doc            
            Builder builder = new Builder();
            Document doc = builder.build("https://api.openweathermap.org/data/2.5/forecast/daily?q=Toronto,CA&mode=xml&units=metric&cnt=7&appid=3f2e224b815c0ed45524322e145149f0");
        
            //create local element to contain info from doc root element
            Element root = doc.getRootElement();
            //create local element to contain info from doc forecast element
            Element forecast = root.getFirstChildElement("forecast");
            //create local elements to contain info from each doc time element
            Elements times = forecast.getChildElements("time");

            //go through each time element go get required info
            for (int i = 0; i < times.size(); i++) {
                //create local element of current day
                Element day = times.get(i);

                //create local elements for child elements of day, symbol and temperature
                Element symbol = day.getFirstChildElement("symbol");
                Element temperature = day.getFirstChildElement("temperature");
          
                //get attribute values from the various created elements
                String condition = symbol.getAttribute("name").getValue();
                String max = temperature.getAttribute("max").getValue();
                String min = temperature.getAttribute("min").getValue();

                //place retrieved attribute values in appropriate arrays
                lowTemp[i] = (int) Double.parseDouble(min);
                highTemp[i] = (int) Double.parseDouble(max);
                conditions[i] = condition;
            }

            //display to the console
            for (int i = 0; i < conditions.length; i++) {
                System.out.println("Day " + i);
                System.out.println("\tConditions: " + conditions[i]);
                System.out.println("\tHigh: " + highTemp[i]);
                System.out.println("\tLow: " + lowTemp[i]);
            }

        } catch (ParsingException ex) {
            Logger.getLogger(XMLWeather.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(XMLWeather.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String[] args) {
        try {
            XMLWeather weather = new XMLWeather();
        } catch (Exception exception) {
            System.out.println("Error: " + exception.getMessage());
        }
    }

}